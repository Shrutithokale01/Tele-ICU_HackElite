# project(29/06) > 2024-06-29 7:46am
https://universe.roboflow.com/project2906-h08qu/project-29-06

Provided by a Roboflow user
License: CC BY 4.0

